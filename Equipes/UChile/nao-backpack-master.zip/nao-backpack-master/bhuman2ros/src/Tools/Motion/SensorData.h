#pragma once

namespace SensorData
{
  enum {off = 10000}; /**< Special value that indicates that a sensor is turned off. */ // TODO: change to constexpr
}