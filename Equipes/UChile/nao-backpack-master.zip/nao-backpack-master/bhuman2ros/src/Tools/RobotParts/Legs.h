#pragma once

#include "Tools/Streams/Enum.h"

namespace Legs
{
  GLOBAL_ENUM(Leg,
  {,
    left,
    right,
  });
}
