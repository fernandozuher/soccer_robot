#pragma once

#include "Tools/Streams/Enum.h"

namespace FsrSensors
{
  GLOBAL_ENUM(FsrSensor,
  {,
    fl,
    fr,
    bl,
    br,
  });
}
